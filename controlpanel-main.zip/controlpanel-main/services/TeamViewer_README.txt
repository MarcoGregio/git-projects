$ sudo apt-get update --allow-releaseinfo-change
$ sudo apt-get update --fix-missing
$ sudo apt-get update --allow-releaseinfo-change
$ sudo apt-get update
$ sudo teamviewer repo disable  se in questa fase non funziona non è un problema, anzi
$ sudo wget https://dl.teamviewer.com/download/linux/version_15x/teamviewer-host_15.5.3_armhf.deb
$ sudo dpkg -i teamviewer-host_15.5.3_armhf.deb 
$ sudo teamviewer repo disable
$ sudo apt-get -f install
       - Dare l’opzione «N» quando richiesto
$ sudo teamviewer repo disable
