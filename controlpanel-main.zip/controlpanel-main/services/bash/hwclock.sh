#! /bin/bash
sudo hwclock --hctosys
