#! /bin/bash
python3 /home/pi/HMI/ControlPanel4/ControlPanel/ControlPanel.py