avrdude_loader.sh carica tramite porta seriale un file ".ino.mega.hex" sul plc.
Incollare il file che vuoi caricare in questa cartella rinominandolo "hexacode.ino.mega.hex"
poi eseguire avrdude_loader.sh
